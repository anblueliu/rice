

document.write("<link href=\"/css/common.css?v=12334\" rel=\"stylesheet\" />");
document.write("<link href=\"/css/ydui.css?v=1234\" rel=\"stylesheet\" />");
document.write("<script src=\"/js/jquery.min.js\"></script>");
document.write("<script src=\"/js/ydui.js\"></script>");
document.write("<script src=\"/js/base.js\"></script>");
document.write("<script src=\"/js/iconfont.js\"></script>");
document.write("<script src=\"/js/swiper.min.js\"></script>");



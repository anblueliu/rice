(function(){
    var DomWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var htmlDom = document.getElementsByTagName('html')[0];
        htmlDom.style.fontSize = DomWidth/10+'px';
    addEventListener('resize',function(){
        var DomWidth = document.documentElement.clientWidth || document.body.clientWidth;
        var htmlDom = document.getElementsByTagName('html')[0];
            htmlDom.style.fontSize = DomWidth/10+'px';
    })
})();